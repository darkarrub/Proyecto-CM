//
//  Durán Sánchez Daniela
//  Gasca Guerrero Rubén
//  De Jesús Moreno Yolanda
//

import SwiftUI

//Modelo prodcuto:

struct Product: Identifiable,Hashable{
    var id = UUID().uuidString
    var type: ProductType
    var title: String
    var description: String = ""
    var price: String
    var productImage: String = ""
    var quantity: Int = 1
}

//Tipo de productos

enum ProductType: String,CaseIterable{
    case Entradas = "Entradas"
    case Plato = "Plato Fuerte"
    case Postres = "Postres"
    case Bebidas = "Bebidas"
}
