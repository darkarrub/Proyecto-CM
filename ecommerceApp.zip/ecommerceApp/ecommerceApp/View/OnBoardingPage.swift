//
//  Durán Sánchez Daniela
//  Gasca Guerrero Rubén
//  De Jesús Moreno Yolanda
//

import SwiftUI

let customFont = "Raleway-Regular"

struct OnBoardingPage: View {
    @State var showLoginPage: Bool = false
    var body: some View {
        
        VStack(alignment: .leading){
            Text("Delicias \nDary's")
                .font(.custom("American Typewriter", size: 55))
                .fontWeight(.bold)
                .foregroundColor(Color.white)
                .offset(y:-110)
                .offset(x: 63)

            //.padding(.top,-50)
                //.padding(.vertical,10)

            Image("Comida")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .offset(y:-30)
                .offset(x:1)
            
            Button{
                withAnimation {
                    showLoginPage = true
                }
            }label: {
                Text("Entrar")
                    .font(.custom("Baskerville", size: 23))
                    .fontWeight(.semibold)
                    .padding(.vertical,18)
                    .frame(maxWidth: .infinity)
                    .background(Color(red: 0.019,  green: 0.415, blue: 0.415))
                    .cornerRadius(30)
                    .shadow(color: Color.black.opacity(0.4), radius: 5, x: 0, y: 5)
                    .foregroundColor(Color.white)
            }
            .padding(.horizontal,60)
            .offset(y:70)
        }
        .padding()
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(
            (Color(red: 0.756, green: 0.509, blue: 0.976))
        )
        .overlay(
        
            Group{
                if showLoginPage{
                    LoginPage()
                        .transition(.move(edge: .trailing))
                }
            }
        )
    }
}

struct OnBoardingPage_Previews: PreviewProvider {
    static var previews: some View {
        OnBoardingPage()
        
    }
}
