//
//  Durán Sánchez Daniela
//  Gasca Guerrero Rubén
//  De Jesús Moreno Yolanda
//

import SwiftUI

import Combine

class HomeViewModel: ObservableObject {
    
    @Published var productType: ProductType = .Entradas
    

    @Published var products: [Product] = [
        Product(type: .Entradas, title: "Sopa de Tortilla", description: "La sopa es elaborada con caldo de jitomates molidos, ajo y cebolla, sazonada con epazote, y servida con tiras fritas de tortilla de maíz y chile pasilla, aguacate, queso asadero o fresco, y crema.", price: "$125.00", productImage: "Sopa"),
    Product(type: .Entradas, title: "Consomé de Pollo", description: "Caldo hecho con carne de pollo, cebolla, ajo y algunas hierbas aromáticas que varían. Puede ser únicamente el caldo o llevar algunas verduras como zanahoria, calabacitas, arroz, garbanzos y papa.", price: "$103.00", productImage: "Consome"),
    Product(type: .Plato, title: "Enchiladas Verdes", description: "Preparadas con tomate, además de llevar cilantro o epazote en su preparación. También pueden ser rellenas de pollo o carne deshebrada, acompañadas con frijoles refritos.", price: "$175.00", productImage: "Enchiladas"),
    Product(type: .Plato, title: "Lasaña", description: "Pasta italiana en forma de cintas, alternadas con capas de salsa Boloñesa, cubierta con queso parmesano rallado y albahaca fresca.", price: "$250.00", productImage: "Lasaña"),
    Product(type: .Postres, title: "Cheesecake de Zarzamora", description: "Delicioso pastel de queso estilo New York, cubierto con mermelada de zarzamora.", price: "$70.00", productImage: "Cheesecake"),
    Product(type: .Postres, title: "Pastel de Chocolate", description: "Deliciosas capas de bizcocho húmedo de chocolate, relleno de una sedosa crema de leche. Cubierto por una mousse de avellanas.", price: "$70.00", productImage: "Chocolate"),
    Product(type: .Bebidas, title: "Agua de horchata", description: "Bebida preparada con granos de arroz remojados en agua y mezclados con leche y canela.", price: "$40.00", productImage: "Horchata"),
    Product(type: .Bebidas, title: "Agua de Jamaica", description: "Refrescante agua elaborada de la infusión de flores de jamaica y endulzada.", price: "$35.00", productImage: "Jamaica")
    ]
    
    //Filtrando los productos
    
    @Published var filteredProducts: [Product] = []
    
    @Published var showMoreProductsOnType: Bool = false
    
    //Busqueda
    @Published var searchText: String = ""
    @Published var searchActivated: Bool = false
    @Published var searchProducts: [Product]?
    
    var searchCancellable: AnyCancellable?

    init(){
        filteredProductByType()
        
        searchCancellable = $searchText.removeDuplicates()
            .debounce(for: 0.5, scheduler: RunLoop.main)
            .sink(receiveValue: { str in
                if str != ""{
                    self.filteredProductBySearch()
                }else{
                    self.searchProducts = nil
                }
            })
    }
    
    func filteredProductByType(){
        
        DispatchQueue.global(qos: .userInteractive).async {
            let results = self.products
                .lazy
                .filter { product in
                    return product.type == self.productType
                }
            //Limitando resultado
                .prefix(4)
            DispatchQueue.main.async {
                self.filteredProducts = results.compactMap({ product in
                    return product
                })
            }
        }
    }
    
    func filteredProductBySearch(){
        
        DispatchQueue.global(qos: .userInteractive).async {
            let results = self.products
                .lazy
                .filter { product in
                    return product.title.lowercased().contains(self.searchText.lowercased())
                }

            DispatchQueue.main.async {
                self.searchProducts = results.compactMap({ product in
                    return product
                })
            }
        }
    }
}
