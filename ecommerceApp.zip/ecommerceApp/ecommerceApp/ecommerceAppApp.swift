//
//  Durán Sánchez Daniela
//  Gasca Guerrero Rubén
//  De Jesús Moreno Yolanda
//

import SwiftUI

@main
struct ecommerceAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
